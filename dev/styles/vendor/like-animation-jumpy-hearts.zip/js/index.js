$('a.like-button').on('click', function() {
  $(this).toggleClass('liked');
});